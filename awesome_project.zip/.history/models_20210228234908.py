import sqlalchemy
from databases import Database
from sqlalchemy import Column, Integer
from sqlalchemy.ext.declarative import declarative_base
database = Database("mysql://qit:qit123456@finone-dev.ck82c53jf6pg.rds.cn-northwest-1.amazonaws.com.cn:3306/dev21_bktest")
Base = declarative_base()
metadata = sqlalchemy.MetaData()
class StrategyLibDir(Base):
    __tablename__ = 'supportplatform_strategylibdir'
    id = Column(Integer, primary_key=True)
    create_time = Column("create_time", sqlalchemy.DateTime(timezone=True), server_default=sqlalchemy.func.now()),
    last_modified_time = Column("last_modified_time", sqlalchemy.DateTime(timezone=True), onupdate=sqlalchemy.func.now()),
    name = Column("name", sqlalchemy.String(length=20), nullable=False),
    Column("level", sqlalchemy.SmallInteger()),
    Column("parent_dir_id", sqlalchemy.ForeignKey("supportplatform_strategylibdir.id"))
)

async def init_database():
    await database.connect()
    query = strategylib_dir.select()
    print(query)
    async for row in database.iterate(query=query):
        print(row)
    await database.disconnect()

import asyncio
loop = asyncio.get_event_loop()
loop.run_until_complete(init_database())
loop.close()

