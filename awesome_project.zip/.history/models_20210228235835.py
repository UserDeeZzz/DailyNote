from databases import Database
from sqlalchemy import Column, Integer, DateTime, String, SmallInteger, ForeignKey, func
from sqlalchemy.ext.declarative import declarative_base

database = Database("mysql://qit:qit123456@finone-dev.ck82c53jf6pg.rds.cn-northwest-1.amazonaws.com.cn:3306/dev21_bktest")
Base = declarative_base()
se

class StrategyLibDir(Base):
    __tablename__ = 'supportplatform_strategylibdir'
    id = Column(Integer, primary_key=True)
    create_time = Column("create_time", DateTime(timezone=True), server_default=func.now()),
    last_modified_time = Column("last_modified_time", DateTime(timezone=True), onupdate=func.now()),
    name = Column("name", String(length=20), nullable=False),
    level = Column("level", SmallInteger()),
    parent_dir = Column("parent_dir_id", ForeignKey("supportplatform_strategylibdir.id"))


async def init_database():
    await database.connect()
    query = dir(StrategyLibDir.metadata)
    print(query)
    async for row in database.iterate(query=query):
        print(row)
    await database.disconnect()

import asyncio

loop = asyncio.get_event_loop()
loop.run_until_complete(init_database())
loop.close()

