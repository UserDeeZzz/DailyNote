from models import strategylib_dir, database
from typing import Optional, Dict, Any, List
from tartiflette import Resolver

@Resolver("Query.strategy_lib")
async def resolve_query_strategy_lib_dir(
    parent: Optional[Any],
    args: Dict[str, Any],
    ctx: Dict[str, Any],
    info: "ResolveInfo",
    ) -> List[Dict[str, Any]]:
    """
    Resolver in charge of returning all recipes.
    :param parent: initial value filled in to the engine `execute` method
    :param args: computed arguments related to the field
    :param ctx: context filled in at engine initialization
    :param info: information related to the execution and field resolution
    :type parent: Optional[Any]
    :type args: Dict[str, Any]
    :type ctx: Dict[str, Any]
    :type info: ResolveInfo
    :return: the list of all recipes
    :rtype: List[Dict[str, Any]]
    """
    query = strategylib_dir.select()
    await database.connect()
    resp = []
    async for row in database.iterate(query=query):
        resp.append(row)
    await database.disconnect()
    return resp