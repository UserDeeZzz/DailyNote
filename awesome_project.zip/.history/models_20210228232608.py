import sqlalchemy
from databases import Database
Database("mysql+mysqlconnector://qit:qit123456@finone-dev.ck82c53jf6pg.rds.cn-northwest-1.amazonaws.com.cn:3306/dev21_bktest")

metadata = sqlalchemy.MetaData()

strategylib_dir = sqlalchemy.Table(
    " supportplatform_strategylibdir",
    metadata,
    sqlalchemy.Column("text", sqlalchemy.String(length=100)),
    sqlalchemy.Column("create_time", sqlalchemy.DateTime(timezone=True), server_default=sqlalchemy.func.now()),
    sqlalchemy.Column("last_modified_time", sqlalchemy.DateTime(timezone=True), onupdate=sqlalchemy.func.now()),
    sqlalchemy.Column("name", sqlalchemy.String(length=20), nullable=False),
    sqlalchemy.Column("level", sqlalchemy.SmallInteger()),
    sqlalchemy.Column
)