from sqlalchemy import Table, MetaData, DateTime, func, String, SmallInteger, ForeignKey, Column
from databases import Database
database = Database(
    "mysql://qit:qit123456@finone-dev.ck82c53jf6pg.rds.cn-northwest-1.amazonaws.com.cn:3306/dev21_bktest"
)

metadata = MetaData()

strategylib_dir = Table(
    "supportplatform_strategylibdir", metadata,
    Column("id", )
    Column("create_time", DateTime(timezone=True), server_default=func.now()),
    Column("last_modified_time", DateTime(timezone=True), onupdate=func.now()),
    Column("name", String(length=20), nullable=False),
    Column("level", SmallInteger()),
    Column("parent_dir_id", ForeignKey("supportplatform_strategylibdir.id")))

